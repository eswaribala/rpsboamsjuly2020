package com.virtusa.kafkaappointmentconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KafkaAppointmentConsumnerApplication {

	public static void main(String[] args) {
		SpringApplication.run(KafkaAppointmentConsumnerApplication.class, args);
	}

}
